# adaptive_calendar
Andrew Dircks and Sam Kantor - Cornell CS 3110 final project. Implements a terminal application for collaborative, time-zone adaptive calendars.
